# Import all routes to make them available for import from app.api.routes
from app.api.routes import auth, users, profile, plans, investments, wallets, network, referrals, uploads, noc, contact, auth_reset_password, bonus, notifications, otp, payments
