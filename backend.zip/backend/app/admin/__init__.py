from app.admin.admin import setup_admin

__all__ = ["setup_admin"]
