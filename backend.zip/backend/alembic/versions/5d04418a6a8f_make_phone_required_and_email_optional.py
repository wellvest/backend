"""Make phone required and email optional

Revision ID: 5d04418a6a8f
Revises: 040f4c22d55c
Create Date: 2025-07-12 22:53:15.419983

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '5d04418a6a8f'
down_revision = '040f4c22d55c'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
