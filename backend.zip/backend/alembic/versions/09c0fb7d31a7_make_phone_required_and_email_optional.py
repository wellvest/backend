"""Make phone required and email optional

Revision ID: 09c0fb7d31a7
Revises: 5d04418a6a8f
Create Date: 2025-07-12 22:54:59.014295

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '09c0fb7d31a7'
down_revision = '5d04418a6a8f'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
