"""Make phone required and email optional

Revision ID: 040f4c22d55c
Revises: 87dbd732dfeb
Create Date: 2025-07-12 22:53:09.262628

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '040f4c22d55c'
down_revision = '87dbd732dfeb'
branch_labels = None
depends_on = None


def upgrade() -> None:
    pass


def downgrade() -> None:
    pass
